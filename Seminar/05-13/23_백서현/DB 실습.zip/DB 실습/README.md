# 제목:mysql로 DB생성 및 POST 요청하기

# 목적: MySQL을 이용해서 DB를 생성하고 POSTMAN을 이용해서 DB에 POST해서 데이터 넣어보기

## 과정

# mysql로 테이블 생성

```
create database seohyun;
use seohyun;

CREATE TABLE users (
  id VARCHAR(50) PRIMARY KEY,
  password VARCHAR(100) NOT NULL
);
```

# 서버 구성

```
/db -> POST 요청으로 등록하는 경로
/result -> GET 요청으로 데이터 전체 조회하는 경로
```

# POSTMAN을 이용해서 POST 요청

![postman](./img/postman.png)

## 결과

# GET 결과

![result](./img/result.png)

# mysql DB 결과

![mysql](./img/mysql.png)
