const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "manager",
  password: "1234",
  database: "seohyun",
});

db.connect((err) => {
  if (err) {
    console.error("MySQL 연결 실패:", err);
    process.exit(1);
  }
  console.log("MySQL 연결 성공");
});

const app = express();
app.use(bodyParser.json());

app.post("/db", (req, res) => {
  const users = Array.isArray(req.body) ? req.body : [req.body];
  const values = users.map((u) => [u.id, u.password]);
  db.query("insert into users (id, password) values ?", [values], (err) => {
    if (err) return res.status(500).send("등록 실패");
    res.send("등록 성공");
  });
});

app.get("/result", (req, res) => {
  db.query("SELECT * FROM users", (err, rows) => {
    if (err) return res.status(500).send("조회 실패");
    res.json(rows);
  });
});

app.listen(3000, () => {
  console.log("서버 실행 중 → http://localhost:3000");
});
