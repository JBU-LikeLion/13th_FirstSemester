// 변수와 제어문으로 피라미드를 그리는 함수 (HTML에서 호출 가능)
function drawPyramidWithVariables() {
    // 입력창에서 층 수 가져오기
    let height = parseInt(document.getElementById('heightInput').value);
    
    // 입력값 제한
    if (height < 1) height = 1;
    if (height > 20) height = 20;

    // 피라미드 패턴을 저장할 변수
    let output = '';

    // 맨 아래층의 별 개수 계산 (이등변삼각형 기준)
    let maxStars = 2 * (height - 1) + 1;

    // 제어문(for 반복문)으로 피라미드 그리기
    for (let i = 0; i < height; i++) {
        // 현재 층의 별 개수
        let stars = 2 * i + 1;

        // 왼쪽 공백 개수 (중앙 정렬)
        let spaces = Math.floor((maxStars - stars) / 2);

        // 공백 추가
        for (let b = 0; b < spaces; b++) {
            output += ' ';
        }

        // 별 추가
        for (let j = 0; j < stars; j++) {
            output += '*';
        }

        // 줄바꿈 추가
        output += '\n';
    }

    // HTML에 피라미드 출력
    document.getElementById('pyramidOutput').textContent = output;
}