// 피라미드 클래스를 정의
class Pyramid {
    // 생성자: 피라미드의 높이를 설정
    constructor(height) {
        this.height = height; // 피라미드 층 수
        this.pattern = ''; // 피라미드 패턴을 저장할 변수
    }

    // 피라미드 패턴을 생성하는 메서드
    generatePattern() {
        this.pattern = ''; // 패턴 초기화

        // 맨 아래층의 별 개수 계산 (이등변삼각형 기준)
        let maxStars = 2 * (this.height - 1) + 1;

        // 각 층을 그리기
        for (let i = 0; i < this.height; i++) {
            // 현재 층의 별 개수
            let stars = 2 * i + 1;

            // 왼쪽 공백 개수 (중앙 정렬)
            let spaces = Math.floor((maxStars - stars) / 2);

            // 공백 추가
            for (let b = 0; b < spaces; b++) {
                this.pattern += ' ';
            }

            // 별 추가
            for (let j = 0; j < stars; j++) {
                this.pattern += '*';
            }

            // 줄바꿈 추가
            this.pattern += '\n';
        }
        return this.pattern;
    }
}

// 클래스 방식으로 피라미드를 그리는 함수 (HTML에서 호출 가능)
function drawPyramidWithClass() {
    // 입력창에서 층 수 가져오기
    let height = parseInt(document.getElementById('heightInput').value);
    
    // 입력값 제한
    if (height < 1) height = 1;
    if (height > 20) height = 20;

    // Pyramid 객체 생성
    const pyramid = new Pyramid(height);

    // 피라미드 패턴 생성 및 출력
    document.getElementById('pyramidOutput').textContent = pyramid.generatePattern();
}